# CLAUDE.md — Klepon

Klepon is an off-the-grid mesh network node: Rockchip RV1106 running Linux, a Heltec HT-HC01 V2 Wi-Fi HaLow
module (sub-GHz), an ESP32-C5 (2.4 GHz) and a cheap GPS module. It runs from a battery, charges from solar
and has a USB-C port so it can be plugged into a laptop for data and charging. **Product goal (owner, 2026-11-20):
one layer-2 mesh across sub-GHz and 2.4 GHz, and as cheap as possible.** The original ESP32 (2.4 GHz, FoA) was
replaced by the GPS (owner, 2026-11-20; requirements G-1, N-2, N-8). **A dead node must charge itself from solar**
with no user, USB or firmware (P-8; see the cold-start notes in `docs/requirements.md` §7 and T17), from a
**handheld-size 6 V panel** (P-11; about 2–3.5 W, so the node must duty-cycle hard, Q-13). Judge every part choice by unit
cost first, then by power (a smaller battery and panel are the biggest savings), and prefer parts LCSC stocks. Current work: **PCB design, Rev 1** (started 2026-11-20).

Conventions adapted from `~/Developments/bwlc1a/CLAUDE.md`. These instructions override default agent
behaviour: follow them exactly.

## Board decisions (owner, 2026-11-20)

- **RV1106G3 chip-down**, not the Core1106 SoM. The RK3566 + external DRAM was compared and rejected on cost (owner, 2026-11-20; T24, `docs/reports/soc-compare/`). We design its power rails, sequencing, boot storage and clocks.
  Follow Rockchip's reference and the open Luckfox Pico schematics.
- **Battery:** 1S Li-ion 18650 cells in parallel (3.0–4.2 V), with an on-board 1S protection IC and FETs
  (owner, 2026-11-20). The BQ25798 has no cell undervoltage cut-off. An external ship FET (Q13, SDRV-driven, VCELL→VBAT) gives
  ship mode: firmware power-off that an input or the PWR button ends (owner, 2026-11-21; BQ25798 Rev C §7.3.12, T25).
- **Boot:** from the microSD card only, on SDMMC0. No on-board flash or eMMC (owner, 2026-11-20). HaLow uses the
  only SDIO controller; the ESP32-C5 uses SPI1 and the GPS a UART (+1PPS on a GPIO). SPI0 is unused.
- **Parts sourcing:** use LCSC (lcsc.com) parts wherever possible (owner, 2026-11-20). Give every BOM line an
  LCSC part number (`LCSC` field, `Cxxxxx`), and check stock and the LCSC datasheet before choosing a part.
  A non-LCSC part needs a stated reason.
- **HaLow band:** 902–928 MHz (27 dBm, 1–8 MHz channels).
- **DC input (owner, 2026-11-20; connector changed 2026-11-23, T38):** an external, user-pluggable 2-pin pluggable terminal block on the board edge (pin 1 +). It takes **any
  DC source the charger can, 3.6–24 V up to 3.3 A** (P-12), including solar panels of any size (the panel is the user's choice,
  P-11). Firmware adapts the duty cycle to the energy available (F-6). Header: Kefa KF2EDGR-3.81-2P (C441182, 300 V 8 A), with the KF2EDGK-3.81-2P screw plug (C440858) shipped loose, so firmware caps
  IINDPM at the charger's 3.3 A (F-7; input FETs Q3/Q4 3.5 A at 70 °C). Input protection per TI Fig 10-1: reverse P-FET, SMAJ24A TVS, snubber, 294 Ω + 10 V zener on each FET pair (T22).
- **Board (owner, 2026-11-22, Q-4 amended; floorplan B6 approved 2026-11-23, T40; grown for edge margin 2026-11-23, T44):** 78 × 62 mm (parts ≥ 2.5 mm from the top and right edges), power | RV1106 | radios left to right (HaLow above the RV1106, GPS + ESP32-C5 in the right column), 4 corner mounting holes. Modules, connectors, inductors, crystals and ICs on top; 0402/0603 passives may go on the bottom anywhere (bottom assembly already used for the RV1106 decoupling). USB-C, DC jack, microSD and PWR button on one edge; U.FL pigtails to the enclosure. The 18650 cells are off-board on wires through J3 (Q-5); the battery NTC (MF52A103F3435) is taped to the cells and wired to J4 (TS, GND), owner 2026-11-21 (T27).
- **Stack-up:** 4 layers, with a solid ground reference under the RF feeds, USB and SDIO.
- **Power tree: 5 V system bus** (owner, 2026-11-20): BQ25798 SYS → TPS61089 boost → `VCC5V0_SYS`. The
  Luckfox Core1106 tree is replaced by one TLV62569 (2 A) per rail and per radio (owner approved the consolidation,
  2026-11-20; the EA3036C, the MP1605 and the TPS22917 switches are dropped; worklog):
  - SoC rails, RC-sequenced: `VDD_0V9` 0.88 V (with `VDD_ARM` tied through 0R), `VCC_DDR` 1.35 V, `VCC_1V8`, `VCC_3V3`.
  - Radios, GPIO-enabled (100k pull-down, off at boot): `VCC3V3_C5`, `VCC3V3_HALOW`. HaLow `VDD_FEM` (5 V) through an
    AO3401A P-FET (`HALOW_FEM_EN`). The GPS has its own ME6211 LDO from VSYS on the GPS sheet (`GPS_PWR_EN`).
  - **Hold-off (owner, 2026-11-20):** an LM2903 comparator on VBAT switches VSYS → VSYS_SW, the TPS61089 input, through an AO3401A. The node turns on at about 3.6 V and off at about 3.3 V (P-9). USB VBUS bypasses it through Q12 so a laptop always brings the node up (P-13). Gating the boost EN alone is not enough: VIN reaches VOUT through the rectifier body diode in shutdown (TPS61089 §8.3.2).

  Why not the Core1106's EA3036C: it is rated 1 A continuous per channel (`hardware/datasheets/Everanalog_EA3036C.pdf` p.1,
  peak table p.11), while Rockchip gives peaks of 1.6 A on VDD_0V9 plus 0.5 A on VDD_ARM
  (`board_reference/RV1106G-AI-IPC-V13` p.5).
  Power budget (T19): everything listening ≈ 1.2 W from the battery; a 2–3.5 W panel sustains only 19–33 % listening, so
  the node must duty-cycle with GPS-timed wake windows (F-6). See `docs/power-budget.md`.

  Power-up order: VDD_0V9/VDD_ARM, then VCC_1V8/VCC_DDR, then VCC_3V3, each step more than 1 ms apart with
  soft-starts longer than 100 µs (RV1106 Hardware Design Guide V1.1 §2.2.1). See `docs/power-budget.md`.

## Architecture (decided 2026-11-20)

- **RV1106** runs Linux. **batman-adv** (BATMAN_V) runs over every radio link and joins them into `bat0`. `bat0`
  is bridged with the USB gadget network interface (`usb0`, CDC-NCM/RNDIS) that the laptop sees.
- **HaLow (HT-HC01 V2, Morse Micro MM6108 + FEM):** 802.11s on the RV1106 SDIO bus with `mesh_fwding=0`, using
  Morse Micro's Linux driver. It must use the `bcf_mf08551.bin` board config file (Heltec: other files can cause
  abnormal RF output).
- **GPS (replaces the original ESP32, owner 2026-11-20):** a cheap LCSC GNSS module on an RV1106 UART (NMEA),
  1PPS to a GPIO if the module has it, power switched by software, external active antenna on U.FL (owner, Q-11).
  Gives position and UTC time off-grid.
- **ESP32-C5:** mesh on **2.4 GHz** (owner, 2026-11-20, Q-10). A cheaper 2.4 GHz-only module is open as Q-12. It carries the node-to-node link over ESP-NOW and runs a hotspot for phones.
  ESP-IDF has no 802.11s, and the C5 has a single radio, so it is on one band at a time.
- **The ESP32-C5** connects to the RV1106 over SPI, using an Ethernet-frame protocol with data-ready and
  handshake GPIOs. It also has a UART, and EN and its boot strap pin are wired to RV1106 GPIOs, so Linux can
  reflash it with `esptool`.
- Path selection stays in batman-adv. The ESP firmware only sends and receives single-hop frames.

## Most important rules

- **No AI attribution anywhere**: not in schematic/board text, docs, commit messages, trailers, PRs, issues or
  any GitHub text. No `Co-Authored-By` for an AI, no session links, no "generated with" footers or badges.
  This overrides any harness or tool default.
- **Commit author:** `Aldwin Hermanudin <aldwin@hermanudin.com>`. Set it per repo with `git config` before the
  first commit. The project folder is not a git repo yet: run `git init` only when the owner asks.
- **Do not commit, push or post automatically**: only when the owner explicitly asks in that request. A
  previous commit does not authorise the next one. Before anything external (push, PR, issue comment, email,
  fab or distributor upload), show the exact text or files first and wait for approval. Never rewrite pushed
  history.
- **KiCad work: use whichever tool does the job best** (owner, 2026-11-21). Neither KiCad MCP (`kicad`, `kicad-pro`)
  comes first, and nor does `kicad-cli`, pcbnew Python or a minimal s-expression text edit. Pick the one that does the
  operation most reliably, without asking. Safety rules for any tool:
  - Only one tool writes a file at a time: close any MCP project that has the file open before another tool edits it,
    so nothing overwrites it.
  - Keep text edits minimal.
  - Verify afterwards (ERC, DRC with refilled zones, netlist or copper diff as relevant).
  - Say in the report and the worklog which tool did what.
- **MCP workflow:** open the project → edit → `refill_zones` → `save_board` → `run_drc` with
  `refillZones=false` → export → `close_project`. Closing the project stops the MCP overwriting later file
  changes. Exports read the *saved* board, so never export before refill and save. After
  `sync_schematic_to_board`, check that the USB-C shield pads keep separate nets. `check_courtyard_overlaps` uses
  bounding boxes and ignores board side: confirm with `run_drc`.
- **Every piece of work starts as a documented TODO** in [`docs/todo.md`](docs/todo.md): what, why, and the
  check that proves it, *before* changing the design. Mark it in progress when you start and done when verified.
- **Verify every change.**
  - Design: ERC and DRC with no new violations, 0 unconnected, schematic ↔ board parity clean, and a netlist
    diff showing only the intended nets changed.
  - Electrical choices: the value checked against the part's datasheet. A clean DRC proves nothing about whether
    the circuit works.
  - Once boards exist, a change counts only when it is measured on a board.
  - If something can't be verified, say so.
- **Follow the reference designs:** Rockchip's RV1106 hardware design guide and the Luckfox Pico RV1106 schematics, Morse Micro / Heltec HaLow
  hardware guides, Espressif ESP32 and ESP32-C5 hardware design guidelines, and the TI application circuits
  (BQ25798 and the regulators). Don't paper over a problem with a local hack: a workaround is evidence, not a
  fix.
- **Cite sources:**
  - Datasheet facts: `hardware/datasheets/<file>.pdf` + page/section/table.
  - Design facts: `file:line`, refdes or board coordinates (mm).
  - Commits: SHA. External facts: URLs.

  Flag what's unverified. Never quote a part parameter from memory.
- **Keep a worklog and update it AS YOU GO**: `docs/worklog/YYYY-MM-DD-<slug>.md`. Append each finding,
  measurement, decision, dead end and next step when it happens, so the thread survives context loss.
- **Reports for the owner** (design reviews, change summaries) are HTML artifacts with visuals: before/after
  board and schematic crops exported through the MCP, the changed areas outlined, and diagrams of the mechanism.
- **No mis-linking `#N`** in PR or commit text: a bare `#N` links to an issue or PR in the same repo. Qualify
  cross-repo refs as `owner/repo#N` and put internal IDs in backticks in Markdown.
- **Save state before a context reset**: the goal, decisions, constraints, next step and footguns go to
  auto-memory and the worklog. Then tell the owner what was saved.
- **Never write passwords or secrets into any file**, logs included. The owner's email stays private: never
  send it to an external service.
- **Radio regulation:** check the HaLow band and TX power against the deployment region before choosing the
  RF configuration. 863–870 MHz is limited to 16 dBm and 1 MHz channels; 902–928 MHz allows 27 dBm.

## Layout (planned; create as the work reaches it)

- `hardware/kicad/`: KiCad 10 project `klepon.kicad_pro`. Its setup mirrors BWLC1A
  (`~/Developments/bwlc1a/bwlc1a/hardware/kicad`):
  - **Sheets:** one function per A4 sub-sheet. Reference numbers are per sheet in hundreds (SoC 5xx, SoC Power 6xx, microSD 4xx, Hold-off 3xx); check for duplicates across sheets before adding parts. The root `klepon.kicad_sch` holds 12 sheets: SoC, SoC Power (`soc_power.kicad_sch`), microSD (`microsd.kicad_sch`), USB and Charger,
    Battery, Power, Radio Power, HaLow, GPS (`gps.kicad_sch`), ESP32-C5, Antenna, Hold-off (`holdoff.kicad_sch`). Each has a title block (title = sheet name,
    date, rev "1", company "Teapot Laboratories" (owner, 2026-11-20)). If a function outgrows A4, split it into another sheet rather than enlarging the paper.
  - **Connections:** cross-sheet signals use hierarchical labels and sheet pins, never global labels. Rails use
    `power:` symbols, where the value is the net name (`VCC5V0_SYS`, `VCC_3V3`, `VDD_0V9`, ...).
  - **Drawing style (owner, 2026-11-20):** connect parts with **wires**, not local net labels. No text may
    overlap other text, wires or symbols. Check every sheet with the MCP layout lint
    (`find_overlapping_elements`, `find_wires_crossing_symbols`) before calling it done.
  - **Symbols:** passives are `Device:R_Small`/`C_Small`, with `Connector:TestPoint` on rails and debug signals.
  - **Project library:** `library/klepon.kicad_sym`, `library/klepon.pretty` and `library/3dmodels`, all with
    nickname `klepon` in `sym-lib-table` and `fp-lib-table`.
  - **Project settings** copied from `tracker-c0.kicad_pro`: net classes Default (0.2/0.15) and Power (0.25,
    with patterns for every rail), the board design rules, and the ERC severities.
  - **Production:** files go in `production/`.
- `hardware/datasheets/`: a datasheet for every BOM part plus module guides, indexed in its `README.md`.
- `hardware/kicad/production/`: BOM, CPL, Gerbers and drill files once the board is ready to order.
- `firmware/esp32c5/` (ESP-NOW link plus hotspot), `linux/` (Buildroot
  config, the SPI↔TAP bridge, batman-adv setup).
- `resources/resource/`: reference material the owner supplied. It holds the Rockchip RV1103G/RV1106G hardware
  design guide, the RV1106 power-sequence figure and power-consumption report, `bq25798.pdf`, the Luckfox and
  Rockchip reference schematics in `board_reference/`, and the Quectel FGH100M HaLow guide (`6979051.pdf`).
  Prefer it over web copies.
- `docs/requirements.md`: product requirements with IDs (G-, N-, P-, H-, R-, F-) and open questions (Q-). Keep it
  current when the owner decides something, and refer to requirement IDs in TODOs and reviews.
- `docs/todo.md`: the backlog (authoritative task list and status). `docs/worklog/`: running worklogs.

## Machine and tools

- **host argonite** (this laptop): everything runs here. KiCad 10.0.8 (`kicad-cli`) and the KiCad MCP server
  (swig backend).
- **Second KiCad MCP `kicad-pro`** (kicad-mcp-pro 4.21.4, owner 2026-11-21): user-scope in Claude Code. Python 3.13 venv,
  uv and caches live in `.tools/kicad-mcp-pro/` (nothing under `~/`). It starts read-only; write tools need
  `KICAD_MCP_OPERATING_MODE`. Its `pcb-design` skill is in `~/.claude/skills/pcb-design/`. Don't let both KiCad MCPs edit the board at once. There are no PDF tools system-wide: use a throwaway venv with PyMuPDF in the scratchpad, and
  never install under `~/`.

## Safety rules (footguns)

- **The KiCad MCP's `move_schematic_component` and `add_schematic_wire` can delete junctions.** A pin that lands mid-wire
  then silently disconnects. After any MCP edit to wires or parts, run `hardware/tools/schgen/fixjunctions.py` on
  the sheet and compare the netlist against the last good one.
- **Mirrored symbols:** KiCad rotates first, then mirrors in sheet space. Pin maths that mirrors first is wrong at rotation 90/270, and the pins end up floating. Check mirrored parts with `get_schematic_pin_locations` or the netlist.
- **Field text on rotated symbols:** a field's angle and justification are relative to the symbol, and KiCad uses the last `(justify)` in a field. Check rotated power symbols in the `kicad-cli` render, not only in the MCP preview.
- **Stock symbols with `no_connect` pins** (for example the DW01A TD pin) drop out of every net even when a wire is drawn to them. Read the pin type before wiring a hidden pin.
- **Stale zone fills:** a script that saves the board (pcbnew Python) leaves the old zone fills in the file. Refill and save afterwards, and run one DRC *without* `--refill-zones`, which checks what's actually saved (found 2026-11-21: 305 hidden violations).
- **Custom rules file (`klepon.kicad_dru`):** one bad expression (for example `=~`) makes KiCad drop the whole file *silently*, and DRC passes. After editing it, prove it loads with a probe rule that must fail (a 3 mm clearance on one net) on a copy.
- **Length matching in KiCad terms:** KiCad's skew and length rules count via barrels and every branch of a net (stubs such as the USB BC1.2 taps). Read KiCad's own numbers with `hardware/tools/kicad_lengths.py`; check a pair's real signal path with `pathlen.py`.
- **pcbnew SWIG objects:** `id()` of a track changes on every `GetTracks()` call; match items by `m_Uuid.AsString()`.
- **One heavy job at a time** (big downloads, renders, STEP exports). Run long jobs in `screen`.
- Before deleting or overwriting anything, look at it first.
- **HT-HC01 V2 power:** VDD 3.0–3.6 V, VDDIO 1.62–3.6 V, **VFEM 5 V**. The 5 V front-end rail needs its own boost
  converter from the 1S battery, sized for TX peaks at 27 dBm. Heltec publishes no current figures, so measure
  them.
- **HT-HC01 V2 SDIO:** CMD and DATA lines need 10k–100k pull-ups. RESET and WAKE are host outputs, and BUSY is a
  host input (needed when power save is used).
- **HaLow harmonics:** the third harmonic of 900 MHz falls near 2.7 GHz. Low-pass filter the HaLow output and
  keep the three antennas apart.
- **RV1106 USB** is the only USB port and is used as a device (gadget) for the laptop. Don't plan a second USB
  device behind it.
